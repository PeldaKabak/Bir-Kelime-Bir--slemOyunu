﻿namespace Bir_Islem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btnsayi1 = new System.Windows.Forms.Button();
            this.Btnsayi2 = new System.Windows.Forms.Button();
            this.Btnsayi3 = new System.Windows.Forms.Button();
            this.Btnsayi4 = new System.Windows.Forms.Button();
            this.Btnsayi5 = new System.Windows.Forms.Button();
            this.Btnsayi6 = new System.Windows.Forms.Button();
            this.Btnsayi7 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Btnsayigetir = new System.Windows.Forms.Button();
            this.BtnYeniOyun = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // Btnsayi1
            // 
            this.Btnsayi1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi1.Location = new System.Drawing.Point(22, 143);
            this.Btnsayi1.Name = "Btnsayi1";
            this.Btnsayi1.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi1.TabIndex = 0;
            this.Btnsayi1.UseVisualStyleBackColor = false;
            this.Btnsayi1.Visible = false;
            // 
            // Btnsayi2
            // 
            this.Btnsayi2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi2.Location = new System.Drawing.Point(116, 143);
            this.Btnsayi2.Name = "Btnsayi2";
            this.Btnsayi2.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi2.TabIndex = 1;
            this.Btnsayi2.UseVisualStyleBackColor = false;
            this.Btnsayi2.Visible = false;
            // 
            // Btnsayi3
            // 
            this.Btnsayi3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi3.Location = new System.Drawing.Point(210, 143);
            this.Btnsayi3.Name = "Btnsayi3";
            this.Btnsayi3.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi3.TabIndex = 2;
            this.Btnsayi3.UseVisualStyleBackColor = false;
            this.Btnsayi3.Visible = false;
            // 
            // Btnsayi4
            // 
            this.Btnsayi4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi4.Location = new System.Drawing.Point(304, 143);
            this.Btnsayi4.Name = "Btnsayi4";
            this.Btnsayi4.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi4.TabIndex = 3;
            this.Btnsayi4.UseVisualStyleBackColor = false;
            this.Btnsayi4.Visible = false;
            // 
            // Btnsayi5
            // 
            this.Btnsayi5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi5.Location = new System.Drawing.Point(398, 143);
            this.Btnsayi5.Name = "Btnsayi5";
            this.Btnsayi5.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi5.TabIndex = 4;
            this.Btnsayi5.UseVisualStyleBackColor = false;
            this.Btnsayi5.Visible = false;
            // 
            // Btnsayi6
            // 
            this.Btnsayi6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi6.Location = new System.Drawing.Point(492, 143);
            this.Btnsayi6.Name = "Btnsayi6";
            this.Btnsayi6.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi6.TabIndex = 5;
            this.Btnsayi6.UseVisualStyleBackColor = false;
            this.Btnsayi6.Visible = false;
            // 
            // Btnsayi7
            // 
            this.Btnsayi7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayi7.Location = new System.Drawing.Point(644, 143);
            this.Btnsayi7.Name = "Btnsayi7";
            this.Btnsayi7.Size = new System.Drawing.Size(88, 50);
            this.Btnsayi7.TabIndex = 6;
            this.Btnsayi7.UseVisualStyleBackColor = false;
            this.Btnsayi7.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(595, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 32);
            this.label1.TabIndex = 8;
            this.label1.Text = "=";
            this.label1.Visible = false;
            // 
            // Btnsayigetir
            // 
            this.Btnsayigetir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btnsayigetir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnsayigetir.Location = new System.Drawing.Point(159, 237);
            this.Btnsayigetir.Name = "Btnsayigetir";
            this.Btnsayigetir.Size = new System.Drawing.Size(169, 35);
            this.Btnsayigetir.TabIndex = 9;
            this.Btnsayigetir.Text = "Sayi Getir";
            this.Btnsayigetir.UseVisualStyleBackColor = false;
            this.Btnsayigetir.Click += new System.EventHandler(this.Btnsayigetir_Click);
            // 
            // BtnYeniOyun
            // 
            this.BtnYeniOyun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnYeniOyun.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnYeniOyun.Location = new System.Drawing.Point(398, 237);
            this.BtnYeniOyun.Name = "BtnYeniOyun";
            this.BtnYeniOyun.Size = new System.Drawing.Size(169, 35);
            this.BtnYeniOyun.TabIndex = 11;
            this.BtnYeniOyun.Text = "Yeni Oyun";
            this.BtnYeniOyun.UseVisualStyleBackColor = false;
            this.BtnYeniOyun.Click += new System.EventHandler(this.BtnYeniOyun_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.richTextBox1.Location = new System.Drawing.Point(232, 26);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(267, 96);
            this.richTextBox1.TabIndex = 12;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(777, 342);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.BtnYeniOyun);
            this.Controls.Add(this.Btnsayigetir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Btnsayi7);
            this.Controls.Add(this.Btnsayi6);
            this.Controls.Add(this.Btnsayi5);
            this.Controls.Add(this.Btnsayi4);
            this.Controls.Add(this.Btnsayi3);
            this.Controls.Add(this.Btnsayi2);
            this.Controls.Add(this.Btnsayi1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btnsayi1;
        private System.Windows.Forms.Button Btnsayi2;
        private System.Windows.Forms.Button Btnsayi3;
        private System.Windows.Forms.Button Btnsayi4;
        private System.Windows.Forms.Button Btnsayi5;
        private System.Windows.Forms.Button Btnsayi6;
        private System.Windows.Forms.Button Btnsayi7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btnsayigetir;
        private System.Windows.Forms.Button BtnYeniOyun;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

